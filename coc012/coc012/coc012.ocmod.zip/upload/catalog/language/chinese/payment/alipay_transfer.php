<?php
// Text
$_['text_title']       = '支付宝转帐';
$_['text_instruction'] = '支付宝转帐说明:';
$_['text_description'] = '<strong>请将订单总额转账到以下支付宝账户。</strong>';
$_['text_payment']     = '<font size="+2" color="#FF0000"><strong>进行支付宝转账时，请务必注明您的订单号</strong></font>，以方便进行核查并及时给您发货！';
?>