<?php
// Text
$_['text_title']				= 'Alipay Transfer';
$_['text_instruction']			= 'Alipay Transfer Instructions';
$_['text_description']			= 'Please transfer the total amount to the following alipay account.';
$_['text_payment']				= 'Your order will not ship until we receive payment.';